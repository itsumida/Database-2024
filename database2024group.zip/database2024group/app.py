from flask import Flask, abort, g, redirect, render_template, request, url_for
import sqlite3

DATABASE = "database.db"

app = Flask(__name__)

students1 = []

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db 


@app.teardown_appcontext
def close_db(exception):
    db = g.pop("db", None)
    if db is not None:
        db.close()

@app.route("/")
def index():
    return render_template('index.html')


    
@app.route("/questionnaire/page", methods=["GET", "POST"])
def questionnaire():
    cursor = get_db().cursor()
    #creating global variables
    form_data = {}  
    error_message = None  
    student_id = None
    teacher_id = None
    fav_course_id = None
    partner1_id = None
    partner2_id = None
    partner3_id = None
    
    if request.method == "POST":
        try:
            form = request.form
            student_id = int(form.get("student_id"))
            teacher_id = int(form.get("teacher_id"))
            fav_course_id = int(form.get("course_id")) 
            partner1_id = int(form.get("partner1_id"))
            partner2_id = int(form.get("partner2_id"))
            partner3_id = int(form.get("partner3_id"))

            # checking if the selected partners are unique
            if partner1_id == partner2_id or partner1_id == partner3_id or partner2_id == partner3_id:
                error_message = "Please select three unique partners."
            else:
                cursor.execute("BEGIN")

                #checking if the student has already submitted a questionnaire
                cursor.execute("""
                    SELECT student_id
                    FROM pair
                    WHERE student_id = ?
                    LIMIT 1
                """, [student_id])
                existing_pair = cursor.fetchone()
                if existing_pair:
                    return render_template("questionnaire_already_answered.html")

                #checking if the selected partners include the student themselves
                if student_id in [partner1_id, partner2_id, partner3_id]:
                    error_message = "Please select partners other than yourself."
                else:
                    #checking if the selected teacher matches the student's actual homeroom teacher
                    cursor.execute("""
                        SELECT id
                        FROM student
                        WHERE id = ? AND class_id = ?
                        LIMIT 1
                    """, [student_id, teacher_id])
                    student_teacher_matching = cursor.fetchone()
                    if not student_teacher_matching:
                        error_message = "You must select the homeroom teacher of your own class."
                    else:
                        #if no errors are found, update the database
                        cursor.execute("""
                            UPDATE student
                            SET pcourse_id = ?
                            WHERE id = ?
                        """, (fav_course_id, student_id))

                        cursor.execute("""
                            INSERT INTO pair (student_id, partner_id, preference_rank)
                            VALUES (?, ?, 1), (?, ?, 2), (?, ?, 3)
                        """, (student_id, partner1_id, student_id, partner2_id, student_id, partner3_id))
                        cursor.execute("COMMIT")

                        return render_template("thank_you.html")
        except (TypeError, ValueError, sqlite3.DatabaseError):
            error_message = "An error occurred. Please try again."

    cursor.execute("SELECT * FROM student")
    students = cursor.fetchall()
    teachers = cursor.execute("SELECT * FROM teacher")
    teachers = cursor.fetchall()
    courses = cursor.execute("SELECT * FROM course")
    courses = cursor.fetchall()
    
    #setting a dictionary called form_data with the selected values to pass them back to the template
    form_data = {
        "student_id": student_id,
        "teacher_id": teacher_id,
        "course_id": fav_course_id,
        "partner1_id": partner1_id,
        "partner2_id": partner2_id,
        "partner3_id": partner3_id
    }

    return render_template("questionnaire.html", students=students, teachers=teachers, courses=courses, form_data=form_data, error_message=error_message)

           

@app.route("/summary/page")
def summary():
    cursor = get_db().cursor()
    cursor.execute("""
            SELECT s1.id AS student_id, s1.first_name AS student_first_name, 
                s1.last_name AS student_last_name,
                s2.id AS partner_id,
                s2.first_name AS partner_first_name, 
                s2.last_name AS partner_last_name, 
                c1.title AS student_course_title,
                c2.title AS partner_course_title

            FROM pair p1
            JOIN pair p2 ON p1.student_id = p2.partner_id AND p1.partner_id = p2.student_id AND p1.student_id < p2.student_id
            JOIN student s1 ON p1.student_id = s1.id
            JOIN student s2 ON p2.student_id = s2.id
            JOIN course c1 ON s1.pcourse_id = c1.id
            JOIN course c2 ON s2.pcourse_id = c2.id
""")
    pairs = cursor.fetchall()

    #CODE FOR COMPUTING POPULAR STUDENTS

    popular_students = {}
    cursor.execute("SELECT DISTINCT class_id FROM student")
    class_ids = cursor.fetchall()
    for class_id in class_ids:
        cursor.execute("""
    SELECT s.first_name, s.last_name
    FROM student s
    WHERE s.class_id = ?
    ORDER BY (
        SELECT COUNT(*)
        FROM pair p
        WHERE p.partner_id = s.id
        AND p.preference_rank = 1
    ) DESC LIMIT 3
""", (class_id['class_id'],))
        popular_students[class_id['class_id']] = cursor.fetchall()

    #CODE FOR COMPUTING POPULAR COURSES
        
    cursor.execute("""
         SELECT c.title, student.pcourse_id
         FROM course c, student
         JOIN student s ON c.id = student.pcourse_id
         GROUP BY c.title
         ORDER BY COUNT(*) DESC
     """)
    popular_courses = cursor.fetchall()

    return render_template("summary.html", pairs=pairs, popular_students=popular_students, popular_courses=popular_courses)

if __name__ == "__main__":
    app.run(debug=True)
  
            


    



    





